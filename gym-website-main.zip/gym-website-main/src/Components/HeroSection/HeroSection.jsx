import React from 'react';
import { Form, Button } from 'react-bootstrap';
import './HeroSection.css';

const HeroSection = () => {
  return (
    <section className="hero-section">
     <div className="container maintext bg-transparent">
        <div className="row align-items-center  ">
          <div className="col-lg-7 text-area">
            <div className="hero-text animate-text">
              <span>FUEL YOUR BODY</span>
              <h1>
                Track Your <span className="highlight">Fitness</span> <br />
                with our BMI <span className="highlight">Calculator</span>
              </h1>
              <p>
                Take the guesswork out of your health. Use our intuitive BMI calculator
                and kickstart your transformation today.
              </p>
              <a href="#" className="primary-btn">Get Started</a>
            </div>
          </div>
          <div className="col-lg-5">
            <div className="form-container glass-box animate-form">
              <h3>Let’s Train!</h3>
              <Form>
                <Form.Group className="form-floating mb-3">
                  <Form.Control type="text" placeholder="Name" />
                  <Form.Label>Name</Form.Label>
                </Form.Group>
                <Form.Group className="form-floating mb-3">
                  <Form.Control type="email" placeholder="Email" />
                  <Form.Label>Email</Form.Label>
                </Form.Group>
                <Form.Group className="form-floating mb-3">
                  <Form.Control as="textarea" placeholder="Message" style={{ height: '100px' }} />
                  <Form.Label>Message</Form.Label>
                </Form.Group>
                <Button className="formbtn" type="submit">Send Message</Button>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
