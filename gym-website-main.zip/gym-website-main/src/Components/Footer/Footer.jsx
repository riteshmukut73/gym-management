import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="ACS-footer-footer">
      <div className="ACS-footer-footer-top">
        <div className="ACS-footer-footer-item">
          <div className="ACS-footer-footer-label">YEAR FOUNDED</div>
          <div className="ACS-footer-footer-value">2024</div>
        </div>
        <div className="ACS-footer-footer-item">
          <div className="ACS-footer-footer-label">LOCATION</div>
          <div className="ACS-footer-footer-value">Sector 63, Noida</div>
        </div>
      </div>
      <div className="ACS-footer-footer-middle">
        <div className="ACS-footer-footer-contact">
          <div><h3>Get in touch</h3></div>
          <div>WebXcustomerhelp@gmail.com</div>
          <div>+91 9898989898</div>
          <div>0123456789</div>
        </div>
        <div className="ACS-footer-footer-connect">
          <div><h3>Connect</h3></div>
          <div>LinkedIn</div>
          <div>Instagram</div>
          <div>Twitter</div>
          <div>Facebook</div>
          <div>YouTube</div>
        </div>
        <div className="ACS-footer-footer-services">
          <div><h3>About WebX Learner</h3></div>
          <div>
            WebX Learner is a YouTube channel dedicated to web development, full-stack projects, and modern tech tutorials. 
            ,
          </div>
       
        </div>
        <div className="ACS-footer-footer-ventures">
          <div><h3>Location</h3></div>
          <div>Building #101, Tech Avenue</div>
          <div>Innovation Park, Sector 21</div>
          <div>New City, State 000000</div>
        </div>
      </div>
      <div className="ACS-footer-footer-bottom">
        <div className="ACS-footer-footer-nav">
          <button>Profile</button>
          <button>Services</button>
          <button>Work</button>
          <button>Contact</button>
        </div>
        <div className="ACS-footer-footer-info">
          <div>Terms of Service</div>
          <div>&copy; 2024 WebX Learner</div>
          <div>All Rights Reserved.</div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
