import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Gallery = () => {
  const styles = {
    section: {
      padding: '80px 0',
      backgroundColor: '#101010',
      color: '#fff',
      fontFamily: 'Poppins, sans-serif',
    },
    heading: {
      fontSize: '48px',
      color: '#ff6347',
      textAlign: 'center',
      fontWeight: '700',
      marginBottom: '60px',
      textTransform: 'uppercase',
      letterSpacing: '2px',
    },
    row: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '30px',
      justifyContent: 'center',
    },
    col: {
      position: 'relative',
      flex: '1 1 calc(33.33% - 30px)',
      marginBottom: '30px',
      borderRadius: '10px',
      overflow: 'hidden',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    },
    img: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      borderRadius: '10px',
      transition: 'transform 0.3s ease, opacity 0.3s ease',
    },
    hoverEffect: {
      transform: 'scale(1.1)',
      boxShadow: '0 10px 20px rgba(0,0,0,0.4)',
    },
    overlay: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      opacity: 0,
      transition: 'opacity 0.3s ease',
    },
    overlayText: {
      color: '#fff',
      fontSize: '24px',
      fontWeight: '600',
      textTransform: 'uppercase',
    },
    imgContainer: {
      position: 'relative',
      overflow: 'hidden',
      borderRadius: '10px',
    },
  };

  const galleryImages = [
    { src: 'https://via.placeholder.com/800x600?text=Gym+1', alt: 'Gym 1', title: 'Strength Training' },
    { src: 'https://via.placeholder.com/800x600?text=Gym+2', alt: 'Gym 2', title: 'Yoga Session' },
    { src: 'https://via.placeholder.com/800x600?text=Gym+3', alt: 'Gym 3', title: 'Crossfit Workout' },
    { src: 'https://via.placeholder.com/800x600?text=Gym+4', alt: 'Gym 4', title: 'Fitness Group' },
    { src: 'https://via.placeholder.com/800x600?text=Gym+5', alt: 'Gym 5', title: 'Personal Training' },
    { src: 'https://via.placeholder.com/800x600?text=Gym+6', alt: 'Gym 6', title: 'HIIT Session' },
  ];

  return (
    <section style={styles.section}>
      <h2 style={styles.heading}>Our Gym Gallery</h2>
      <div className="container">
        <div className="row" style={styles.row}>
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="col-md-4"
              style={styles.col}
              onMouseEnter={(e) => {
                e.target.querySelector('img').style.transform = styles.hoverEffect.transform;
                e.target.querySelector('.overlay').style.opacity = 1;
              }}
              onMouseLeave={(e) => {
                e.target.querySelector('img').style.transform = '';
                e.target.querySelector('.overlay').style.opacity = 0;
              }}
            >
              <div style={styles.imgContainer}>
                <img src={image.src} alt={image.alt} style={styles.img} />
                <div className="overlay" style={styles.overlay}>
                  <span style={styles.overlayText}>{image.title}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;
