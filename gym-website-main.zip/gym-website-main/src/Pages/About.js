import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const About = () => {
  return (
    <section
      className="container-fluid py-5 position-relative"
      style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1560807707-8cc7777e8b1d)', 
        backgroundSize: 'cover',
        backgroundPosition: 'center center',
        color: '#fff',
        fontFamily: 'Poppins, sans-serif',
        minHeight: '100vh',
        position: 'relative',
      }}
    >
      <div
        className="w-full position-relative"
        style={{
          background: 'rgba(0, 0, 0, 0.91)',  // Dark overlay for readability
          borderRadius: '20px',
          padding: '60px 40px',
          boxShadow: '0 12px 24px rgba(0, 0, 0, 0.5)',
          zIndex: '1',
        }}
      >
        <div className="row align-items-center">
          {/* Left section: Image */}
          <div className="col-lg-6 mb-4 mb-lg-0">
            <div className="img-container position-relative">
              <img
                src="https://images.unsplash.com/photo-1585100205141-d5e0464695f3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwzNjUyOXwwfDF8c2VhY2h8MXx8Z2ltJTIwd29ya3xlbnwwfDB8fHwtHkI8LR5n96fQA"
                alt="Gym workout"
                className="img-fluid rounded shadow-lg transform-hover"
                style={{
                  border: '4px solid #f15d44',
                  borderRadius: '10px',
                  transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                }}
              />
            </div>
          </div>

          {/* Right section: Text */}
          <div className="col-lg-6 text-center text-lg-left">
            <h2
              className="display-4 text-warning mb-4"
              style={{
                fontWeight: '700',
                fontSize: '2.5rem',
                letterSpacing: '2px',
                textTransform: 'uppercase',
                textShadow: '3px 3px 6px rgba(0, 0, 0, 0.5)',
                borderBottom: '4px solid #f15d44',
                paddingBottom: '10px',
              }}
            >
              Welcome to IronCore Gym
            </h2>
            <p
              className="lead mb-4"
              style={{
                fontSize: '1.1rem',
                lineHeight: '1.8',
                fontWeight: '400',
                opacity: '0.9',
                letterSpacing: '1px',
              }}
            >
              IronCore Gym isn't just a fitness center; it’s a place where you can
              push your limits and transform yourself. With state-of-the-art
              equipment, top-tier trainers, and a welcoming community, we create
              an environment designed to empower you to reach your full potential.
            </p>

            <p
              className="lead mb-4"
              style={{
                fontSize: '1.1rem',
                lineHeight: '1.8',
                fontWeight: '400',
                opacity: '0.9',
                letterSpacing: '1px',
              }}
            >
              Whether you’re starting your fitness journey or refining your
              athleticism, we are here to support you every step of the way.
            </p>

            <a
              href="/classes"
              className="btn btn-danger btn-lg mt-4 px-5 py-3"
              style={{
                padding: '15px 50px',
                fontWeight: '700',
                fontSize: '1.2rem',
                borderRadius: '30px',
                boxShadow: '0 12px 24px rgba(0, 0, 0, 0.3)',
                textTransform: 'uppercase',
                transition: 'all 0.3s ease',
              }}
            >
              Join Us Today
            </a>
          </div>
        </div>
      </div>

      {/* Overlay with subtle parallax */}
      <div
        className="parallax-overlay"
        style={{
          position: 'absolute',
          top: '0',
          left: '0',
          width: '100%',
          height: '100%',
          background: 'rgba(0, 0, 0, 0.7)',
          zIndex: '-1',
          transform: 'scale(1.1)',
        }}
      />
    </section>
  );
};

export default About;
