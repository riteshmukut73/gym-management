import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Classes = () => {
  const classData = [
    { 
      title: 'HIIT Strength', 
      desc: 'High-intensity circuit workouts with weights for max burn.', 
      icon: 'fas fa-dumbbell' 
    },
    { 
      title: 'Boxing Bootcamp', 
      desc: 'Kick, punch, and sweat your way into shape.', 
      icon: 'fas fa-fist-raised' 
    },
    { 
      title: 'Power Yoga', 
      desc: 'Flexibility and strength through mindful movements.', 
      icon: 'fas fa-spa' 
    },
    { 
      title: 'CrossFit Challenge', 
      desc: 'Olympic lifts + endurance workouts for elite training.', 
      icon: 'fas fa-random' 
    }
  ];

  const sectionStyle = {
    backgroundColor: '#1a1a1a',
    color: '#fff',
    padding: '60px 20px',
    fontFamily: 'Poppins, sans-serif',
  };

  const headingStyle = {
    color: '#eb3c5a',
    fontSize: '38px',
    fontWeight: '700',
    letterSpacing: '1px',
    textTransform: 'uppercase',
    marginBottom: '30px',
  };

  const classBoxStyle = {
    background: '#292929',
    borderRadius: '15px',
    padding: '30px',
    boxShadow: '0 12px 24px rgba(0, 0, 0, 0.4)',
    transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
    textAlign: 'center',
    marginBottom: '20px',
  };

  const classBoxHoverStyle = {
    transform: 'translateY(-10px)',
    boxShadow: '0 15px 30px rgba(0, 0, 0, 0.6)',
  };

  const iconContainerStyle = {
    marginBottom: '20px',
  };

  const iconStyle = {
    fontSize: '40px',
    color: '#f67831',
    transition: 'color 0.3s ease',
  };

  const classTitleStyle = {
    color: '#f67831',
    fontSize: '24px',
    fontWeight: '600',
    marginBottom: '10px',
    textTransform: 'uppercase',
  };

  const classDescStyle = {
    color: '#ccc',
    fontSize: '16px',
    lineHeight: '1.5',
    opacity: 0.9,
  };

  const buttonStyle = {
    backgroundColor: '#eb3c5a',
    color: 'white',
    padding: '10px 30px',
    fontWeight: '600',
    borderRadius: '50px',
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  };

  const buttonHoverStyle = {
    backgroundColor: '#f15d44',
    transform: 'translateY(-5px)',
  };

  return (
    <section style={sectionStyle}>
      <div className="container">
        <h2 style={headingStyle}>Our Classes</h2>
        <div className="row">
          {classData.map((cls, idx) => (
            <div key={idx} className="col-md-6 col-lg-3">
              <div
                style={classBoxStyle}
                className="class-box"
                onMouseEnter={(e) => e.target.style = { ...classBoxStyle, ...classBoxHoverStyle }}
                onMouseLeave={(e) => e.target.style = classBoxStyle}
              >
                <div style={iconContainerStyle}>
                  <i className={`${cls.icon} icon`} style={iconStyle} />
                </div>
                <h3 style={classTitleStyle}>{cls.title}</h3>
                <p style={classDescStyle}>{cls.desc}</p>
                <a
                  href="/contact"
                  style={buttonStyle}
                  onMouseEnter={(e) => e.target.style = { ...buttonStyle, ...buttonHoverStyle }}
                  onMouseLeave={(e) => e.target.style = buttonStyle}
                  className="btn btn-danger btn-sm"
                >
                  Join Now
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Classes;
