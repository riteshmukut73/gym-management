import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Contact = () => {
  const styles = {
    section: {
      padding: '80px 0',
      backgroundColor: '#101010',
      color: '#fff',
      fontFamily: 'Poppins, sans-serif',
    },
    heading: {
      fontSize: '48px',
      color: '#ff6347',
      textAlign: 'center',
      fontWeight: '700',
      marginBottom: '60px',
      textTransform: 'uppercase',
      letterSpacing: '2px',
    },
    formContainer: {
      backgroundColor: '#292929',
      padding: '40px',
      borderRadius: '12px',
      boxShadow: '0 10px 30px rgba(0, 0, 0, 0.3)',
    },
    form: {
      display: 'grid',
      gap: '20px',
      maxWidth: '600px',
      margin: '0 auto',
    },
    input: {
      padding: '15px',
      borderRadius: '8px',
      border: '1px solid #444',
      fontSize: '16px',
      backgroundColor: '#2d2d2d',
      color: '#fff',
      transition: 'all 0.3s ease',
    },
    inputFocus: {
      borderColor: '#eb3c5a',
      backgroundColor: '#444',
    },
    button: {
      background: 'linear-gradient(to right, #eb3c5a, #f67831)',
      border: 'none',
      padding: '15px',
      fontSize: '16px',
      color: '#fff',
      borderRadius: '8px',
      cursor: 'pointer',
      fontWeight: 'bold',
      transition: 'background 0.3s ease',
    },
    buttonHover: {
      background: 'linear-gradient(to right, #f67831, #eb3c5a)',
    },
  };

  return (
    <section style={styles.section}>
      <h2 style={styles.heading}>Contact Us</h2>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-8 col-lg-6">
            <div style={styles.formContainer}>
              <form style={styles.form}>
                <input
                  type="text"
                  placeholder="Your Name"
                  style={styles.input}
                  required
                  onFocus={(e) => (e.target.style = { ...styles.input, ...styles.inputFocus })}
                  onBlur={(e) => (e.target.style = styles.input)}
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  style={styles.input}
                  required
                  onFocus={(e) => (e.target.style = { ...styles.input, ...styles.inputFocus })}
                  onBlur={(e) => (e.target.style = styles.input)}
                />
                <input
                  type="tel"
                  placeholder="Your Phone (optional)"
                  style={styles.input}
                  onFocus={(e) => (e.target.style = { ...styles.input, ...styles.inputFocus })}
                  onBlur={(e) => (e.target.style = styles.input)}
                />
                <textarea
                  placeholder="Your Message"
                  rows="5"
                  style={{ ...styles.input, resize: 'none' }}
                ></textarea>
                <button
                  type="submit"
                  style={styles.button}
                  onMouseEnter={(e) => (e.target.style = { ...styles.button, ...styles.buttonHover })}
                  onMouseLeave={(e) => (e.target.style = styles.button)}
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
