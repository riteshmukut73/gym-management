import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const Blog = () => {
  const styles = {
    section: {
      padding: '60px 20px',
      backgroundColor: '#0f0f0f',
      fontFamily: 'Poppins, sans-serif',
      color: '#fff',
    },
    heading: {
      fontSize: '36px',
      color: '#ff3700',
      marginBottom: '40px',
      fontWeight: '700',
      textAlign: 'center',
      textTransform: 'uppercase',
    },
    post: {
      background: '#1c1c1c',
      padding: '20px',
      marginBottom: '20px',
      borderRadius: '10px',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      boxShadow: '0 4px 12px rgba(0,0,0,0.4)',
    },
    postHover: {
      transform: 'translateY(-10px)',
      boxShadow: '0 6px 18px rgba(0,0,0,0.5)',
    },
    title: {
      fontSize: '22px',
      color: '#f67831',
      fontWeight: '600',
      marginBottom: '10px',
      textTransform: 'uppercase',
    },
    content: {
      color: '#bbb',
      fontSize: '16px',
      lineHeight: '1.6',
      opacity: 0.9,
    },
    button: {
      display: 'inline-block',
      marginTop: '20px',
      backgroundColor: '#eb3c5a',
      color: 'white',
      padding: '10px 30px',
      fontWeight: '600',
      borderRadius: '50px',
      textDecoration: 'none',
      textAlign: 'center',
      transition: 'background-color 0.3s ease, transform 0.3s ease',
    },
    buttonHover: {
      backgroundColor: '#f15d44',
      transform: 'translateY(-5px)',
    },
  };

  const posts = [
    { 
      title: 'Top 5 Fat-Burning Exercises', 
      content: 'Discover workouts that burn calories fast and keep your heart racing.' 
    },
    { 
      title: 'Meal Plans for Muscle Gain', 
      content: 'The right nutrition strategy to bulk up without the fluff.' 
    },
    { 
      title: 'Stretching Before and After', 
      content: 'Learn why stretching matters for muscle recovery and injury prevention.' 
    },
  ];

  return (
    <section style={styles.section}>
      <h2 style={styles.heading}>Gym Blog & Tips</h2>
      <div className="container">
        <div className="row">
          {posts.map((post, index) => (
            <div key={index} className="col-md-4">
              <div
                style={styles.post}
                className="post-box"
                onMouseEnter={(e) => e.target.style = { ...styles.post, ...styles.postHover }}
                onMouseLeave={(e) => e.target.style = styles.post}
              >
                <h3 style={styles.title}>{post.title}</h3>
                <p style={styles.content}>{post.content}</p>
                <a
                  href="#"
                  style={styles.button}
                  onMouseEnter={(e) => e.target.style = { ...styles.button, ...styles.buttonHover }}
                  onMouseLeave={(e) => e.target.style = styles.button}
                >
                  Read More
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
