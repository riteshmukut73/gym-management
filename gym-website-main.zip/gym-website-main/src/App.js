// App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import "./App.css";
import About from './Pages/About';
import Blog from './Pages/Blog';
import Classes from './Pages/Classes';
import Gallery from './Pages/Gallery';
import Contact from './Pages/Contact';

import AboutSection from "./Components/AboutSection/AboutSection";
import Footer from "./Components/Footer/Footer";
import MembershipPlans from "./Components/MembershipPlans/MembershipPlans";
import NavBar from "./Components/NavBar/NavBar";
import RegisterSection from "./Components/RegisterSection/RegisterSection";
import UnlimitedClasses from "./Components/UnlimitedClasses/UnlimitedClasses";
import WhatsAppButton from "./Components/WhatsAppButton/WhatsAppButton";
import HeroSection from "./Components/HeroSection/HeroSection";
import Popup from './Popup';

function App() {
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setShowPopup(true);
    }, 60000); 

    return () => clearInterval(intervalId);
  }, []);

  const handleClosePopup = () => setShowPopup(false);

  return (
    <Router>
      <div className="App">
        <NavBar />

        <Routes>
          <Route path="/" element={
            <>
              <HeroSection />
              <RegisterSection />
              <MembershipPlans />
              <WhatsAppButton />
              <UnlimitedClasses />
              <AboutSection />
            </>
          } />
          <Route path="/about" element={<About />} />
          <Route path="/classes" element={<Classes />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>

        <Footer />
        <Popup show={showPopup} handleClose={handleClosePopup} />
      </div>
    </Router>
  );
}

export default App;
